export type AIMode = "coach" | "daily_action" | "problem_solver";

interface AIResponse {
  message: string;
  actionStep?: string;
}

const COACH_RESPONSES: Record<string, AIResponse> = {
  default: {
    message: "I'm here to help you grow. What challenge are you facing today?",
    actionStep: "Write down your top priority for the next 2 hours.",
  },
  motivation: {
    message: "Every expert was once a beginner. The key is consistent, intentional action. Small steps compound into massive results.",
    actionStep: "Commit to one small action you can take in the next 15 minutes.",
  },
  focus: {
    message: "Clarity comes before focus. Let's identify the one thing that moves the needle most for your goal.",
    actionStep: "Block 90 minutes in your calendar this week for deep work on your top goal.",
  },
};

const DAILY_ACTIONS: Record<string, AIResponse[]> = {
  fitness: [
    { message: "Today's focus: Build your foundation.", actionStep: "Do 20 push-ups, 20 squats, and a 10-minute walk. Track it here when done." },
    { message: "Recovery is growth. Your muscles rebuild when you rest.", actionStep: "Stretch for 10 minutes and drink 2L of water today." },
  ],
  business: [
    { message: "Revenue first. Everything else is secondary.", actionStep: "Reach out to 3 potential customers or partners today." },
    { message: "Content is your 24/7 sales rep.", actionStep: "Post one piece of value content on your primary platform." },
  ],
  learning: [
    { message: "Knowledge without application is trivia.", actionStep: "Read for 30 minutes, then implement one insight from what you read." },
    { message: "Teach to learn. Explaining forces clarity.", actionStep: "Write a summary of the most important thing you learned this week." },
  ],
  default: [
    { message: "Progress over perfection. Start before you're ready.", actionStep: "Take one step toward your goal today, however small." },
  ],
};

const PROBLEM_SOLVER_PROMPTS = [
  "Break the problem into smaller pieces. What's the smallest part you can tackle right now?",
  "Consider: what would happen if you did the opposite of what you're currently doing?",
  "Who has solved a similar problem? What can you learn from their approach?",
  "What resources — people, tools, knowledge — do you have but haven't fully used yet?",
  "Rate your problem on a scale of 1-10. Now, what would make it a 5? Start there.",
];

function findKeyword(text: string, keywords: string[]): string | null {
  const lower = text.toLowerCase();
  for (const kw of keywords) {
    if (lower.includes(kw)) return kw;
  }
  return null;
}

export function generateAIResponse(mode: AIMode, userMessage: string, goal?: string): AIResponse {
  const lower = userMessage.toLowerCase();

  switch (mode) {
    case "coach": {
      if (findKeyword(lower, ["motivat", "inspire", "give up", "quit", "hard", "difficult"])) {
        return COACH_RESPONSES.motivation;
      }
      if (findKeyword(lower, ["focus", "distract", "priorit", "overwhelm"])) {
        return COACH_RESPONSES.focus;
      }
      return COACH_RESPONSES.default;
    }

    case "daily_action": {
      const goalKey = goal?.toLowerCase() ?? "default";
      const actions = DAILY_ACTIONS[goalKey] ?? DAILY_ACTIONS.default;
      const action = actions[Math.floor(Math.random() * actions.length)];
      return action;
    }

    case "problem_solver": {
      const response = PROBLEM_SOLVER_PROMPTS[Math.floor(Math.random() * PROBLEM_SOLVER_PROMPTS.length)];
      return {
        message: response,
        actionStep: "Write down 3 possible solutions to your problem, no matter how unconventional.",
      };
    }

    default:
      return COACH_RESPONSES.default;
  }
}

export function generatePostSummary(title: string, content: string): string {
  const words = content.split(" ").length;
  if (words < 20) return content;
  const sentences = content.split(/[.!?]+/).filter(Boolean);
  return sentences.slice(0, 2).join(". ").trim() + ".";
}
