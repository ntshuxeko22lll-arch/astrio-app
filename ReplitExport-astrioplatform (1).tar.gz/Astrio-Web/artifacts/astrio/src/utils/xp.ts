export function xpForLevel(level: number): number {
  return level * 100;
}

export function levelFromXp(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

export function xpProgress(xp: number): number {
  return xp % 100;
}

export function xpToNextLevel(xp: number): number {
  return 100 - xpProgress(xp);
}

export function formatXp(xp: number): string {
  if (xp >= 1000) return `${(xp / 1000).toFixed(1)}k`;
  return `${xp}`;
}
