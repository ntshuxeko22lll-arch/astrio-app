import { useState, useEffect } from "react";
import { Bell } from "lucide-react";
import { Link } from "wouter";
import { useNotifications } from "@/hooks/useNotifications";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function TopBar() {
  const { user } = useAuth();
  const { unreadCount } = useNotifications(user?.id);
  const { profile, updateProfile } = useProfile(user?.id);
  const [goals, setGoals] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("goals").select("*").then(({ data }) => {
      if (data) setGoals(data);
    });
  }, []);

  const handleGoalChange = (val: string) => {
    if (val) updateProfile({ goal: val });
  };

  return (
    <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border px-4 h-14 flex items-center justify-between">
      <div className="flex items-center w-32">
        <Select value={profile?.goal || ""} onValueChange={handleGoalChange}>
          <SelectTrigger className="h-8 text-xs border-none bg-muted/50 focus:ring-0 shadow-none font-semibold text-primary">
            <SelectValue placeholder="Set Goal" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="fitness">Fitness</SelectItem>
            <SelectItem value="business">Business</SelectItem>
            <SelectItem value="learning">Learning</SelectItem>
            <SelectItem value="productivity">Productivity</SelectItem>
            {goals.map(g => (
               <SelectItem key={g.id} value={g.name.toLowerCase()}>{g.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="absolute left-1/2 -translate-x-1/2 text-xl font-bold tracking-tighter bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent cursor-pointer">
        <Link href="/feed">ASTRIO</Link>
      </div>
      
      <div className="w-32 flex justify-end">
        <Link href="/notifications" className="relative p-2 hover:bg-muted rounded-full transition-colors">
          <Bell className="w-5 h-5 text-foreground" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-primary border-2 border-background rounded-full"></span>
          )}
        </Link>
      </div>
    </div>
  );
}
