import { Link, useLocation } from "wouter";
import { Home, MessageSquare, PlusSquare, Brain, User } from "lucide-react";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/feed", icon: Home, label: "Home" },
    { href: "/chat", icon: MessageSquare, label: "Chat" },
    { href: "/create", icon: PlusSquare, label: "Create" },
    { href: "/ai", icon: Brain, label: "AI" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-card/80 backdrop-blur-md border-t border-border flex items-center justify-around px-4 z-50">
      {navItems.map(({ href, icon: Icon, label }) => {
        const isActive = location === href || (href === "/feed" && location === "/");
        return (
          <Link key={href} href={href} className="flex flex-col items-center justify-center w-full h-full p-2">
            <Icon className={`w-6 h-6 transition-all duration-200 ${isActive ? "text-primary drop-shadow-[0_0_8px_rgba(139,92,246,0.8)]" : "text-muted-foreground"}`} />
            <span className={`text-[10px] mt-1 font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>{label}</span>
          </Link>
        );
      })}
    </div>
  );
}
