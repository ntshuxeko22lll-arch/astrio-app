import { useState, useEffect, useRef } from "react";
import { useComments } from "@/hooks/useComments";
import { useAuth } from "@/context/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { X, Send, Loader2, MessageCircle, Trash2 } from "lucide-react";

interface CommentSheetProps {
  postId: string | null;
  postTitle?: string;
  open: boolean;
  onClose: () => void;
  onCountChange?: (postId: string, count: number) => void;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m`;
  if (h < 24) return `${h}h`;
  return `${d}d`;
}

export function CommentSheet({ postId, postTitle, open, onClose, onCountChange }: CommentSheetProps) {
  const { user } = useAuth();
  const { comments, loading, submitting, addComment, deleteComment } = useComments(open ? postId : null);
  const [text, setText] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Notify parent of count changes so feed updates without refetch
  useEffect(() => {
    if (postId && onCountChange) {
      onCountChange(postId, comments.length);
    }
  }, [comments.length, postId, onCountChange]);

  // Focus input when sheet opens
  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 300);
    } else {
      setText("");
    }
  }, [open]);

  // Scroll to bottom when new comments arrive
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [comments.length]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !text.trim() || submitting) return;
    const content = text;
    setText("");
    await addComment(user.id, content);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />

      {/* Sheet */}
      <div
        className={`fixed bottom-0 left-0 right-0 z-50 flex flex-col bg-card border-t border-border rounded-t-2xl transition-transform duration-300 ease-out ${
          open ? "translate-y-0" : "translate-y-full"
        }`}
        style={{ maxHeight: "85dvh" }}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-muted-foreground/25" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-primary" />
            <h2 className="font-bold text-base">
              Comments
              {comments.length > 0 && (
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  {comments.length}
                </span>
              )}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-muted rounded-full transition-colors"
            data-testid="button-close-comments"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {postTitle && (
          <div className="px-4 py-2 bg-muted/30 border-b border-border/30">
            <p className="text-xs text-muted-foreground truncate">
              <span className="font-medium text-foreground/70">On: </span>{postTitle}
            </p>
          </div>
        )}

        {/* Comments list */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 min-h-0">
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-12 h-12 rounded-full bg-muted/40 flex items-center justify-center mb-3">
                <MessageCircle className="w-6 h-6 text-muted-foreground/40" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">No comments yet</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Be the first to reply</p>
            </div>
          ) : (
            comments.map((comment) => {
              const isOwn = comment.user_id === user?.id;
              return (
                <div key={comment.id} className="flex gap-3 group">
                  <Avatar className="h-8 w-8 shrink-0 mt-0.5">
                    <AvatarImage src={comment.profile?.avatar_url ?? ""} />
                    <AvatarFallback className="text-xs bg-primary/10 text-primary">
                      {comment.profile?.username?.[0]?.toUpperCase() ?? "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2 mb-0.5">
                      <span className="text-sm font-semibold leading-none">
                        {comment.profile?.username ?? "User"}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {timeAgo(comment.created_at)}
                      </span>
                    </div>
                    <p className="text-sm text-foreground/90 leading-relaxed whitespace-pre-wrap">
                      {comment.content}
                    </p>
                  </div>
                  {isOwn && (
                    <button
                      onClick={() => deleteComment(comment.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-destructive/10 rounded-full transition-all self-start mt-0.5"
                      data-testid={`button-delete-comment-${comment.id}`}
                    >
                      <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                    </button>
                  )}
                </div>
              );
            })
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="px-4 py-3 border-t border-border/50 bg-background/80 backdrop-blur-sm">
          {!user ? (
            <p className="text-sm text-muted-foreground text-center py-2">Sign in to comment</p>
          ) : (
            <form onSubmit={handleSubmit} className="flex gap-2 items-end">
              <Avatar className="h-7 w-7 shrink-0 mb-1">
                <AvatarImage src={""} />
                <AvatarFallback className="text-xs bg-primary/10 text-primary">
                  {user.email?.[0]?.toUpperCase() ?? "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 relative">
                <Textarea
                  ref={inputRef}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Add a comment... (Enter to send)"
                  rows={1}
                  className="resize-none bg-muted/50 border-border/40 rounded-2xl px-4 py-2.5 text-sm min-h-[40px] max-h-[120px] focus-visible:ring-primary/40 pr-10"
                  style={{ height: "auto" }}
                  data-testid="input-comment"
                />
              </div>
              <Button
                type="submit"
                size="icon"
                disabled={!text.trim() || submitting}
                className="h-9 w-9 rounded-full shrink-0 bg-primary hover:bg-primary/90 shadow-md shadow-primary/20 mb-0.5"
                data-testid="button-submit-comment"
              >
                {submitting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </form>
          )}
        </div>

        {/* Bottom safe area */}
        <div className="h-safe-bottom pb-4" />
      </div>
    </>
  );
}
