import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import type { Database } from "@/types/database";

type Post = Database["public"]["Tables"]["posts"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export interface PostWithProfile extends Post {
  profile: Profile | null;
  liked: boolean;
  action_done: boolean;
}

export function usePosts(userId?: string) {
  const [posts, setPosts] = useState<PostWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: postsData, error: postsError } = await supabase
        .from("posts")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(30);

      if (postsError) throw postsError;

      const enriched: PostWithProfile[] = await Promise.all(
        (postsData ?? []).map(async (post) => {
          const { data: profile } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", post.user_id)
            .single();

          let liked = false;
          let action_done = false;

          if (userId) {
            const { data: likeData } = await supabase
              .from("likes")
              .select("id")
              .eq("post_id", post.id)
              .eq("user_id", userId)
              .maybeSingle();
            liked = !!likeData;

            const { data: actionData } = await supabase
              .from("actions_completed")
              .select("id")
              .eq("post_id", post.id)
              .eq("user_id", userId)
              .maybeSingle();
            action_done = !!actionData;
          }

          return { ...post, profile, liked, action_done };
        })
      );

      setPosts(enriched);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load posts");
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  return { posts, loading, error, refetch: fetchPosts };
}

export async function toggleLike(postId: string, userId: string, liked: boolean) {
  if (liked) {
    await supabase.from("likes").delete().eq("post_id", postId).eq("user_id", userId);
    const { data: post } = await supabase.from("posts").select("likes_count").eq("id", postId).single();
    if (post) {
      await supabase.from("posts")
        .update({ likes_count: Math.max(0, (post.likes_count || 0) - 1) })
        .eq("id", postId);
    }
  } else {
    const { error } = await supabase.from("likes").insert({ post_id: postId, user_id: userId });
    if (!error) {
      const { data: post } = await supabase.from("posts").select("likes_count").eq("id", postId).single();
      if (post) {
        await supabase.from("posts")
          .update({ likes_count: (post.likes_count || 0) + 1 })
          .eq("id", postId);
      }
    }
  }
}

export async function completeAction(postId: string, userId: string) {
  const { error } = await supabase
    .from("actions_completed")
    .insert({ post_id: postId, user_id: userId });

  if (error) return { error };

  // Fetch current profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("xp, completed_actions, streak")
    .eq("id", userId)
    .single();

  if (profile) {
    const newXp = (profile.xp || 0) + 50;
    const newLevel = Math.floor(newXp / 100) + 1;
    await supabase.from("profiles").update({
      xp: newXp,
      level: newLevel,
      completed_actions: (profile.completed_actions || 0) + 1,
      updated_at: new Date().toISOString(),
    }).eq("id", userId);
  }

  // Upsert today's progress
  const today = new Date().toISOString().split("T")[0];
  const { data: existing } = await supabase
    .from("user_progress")
    .select("id, xp_earned, actions_completed")
    .eq("user_id", userId)
    .eq("date", today)
    .maybeSingle();

  if (existing) {
    await supabase.from("user_progress").update({
      xp_earned: (existing.xp_earned || 0) + 50,
      actions_completed: (existing.actions_completed || 0) + 1,
    }).eq("id", existing.id);
  } else {
    await supabase.from("user_progress").insert({
      user_id: userId,
      date: today,
      xp_earned: 50,
      actions_completed: 1,
      streak_day: (profile?.streak || 0) + 1,
    });
  }

  // Notify the user
  await supabase.from("notifications").insert({
    user_id: userId,
    type: "xp",
    title: "+50 XP Earned",
    body: "You completed an action and earned XP. Keep the momentum going!",
  });

  return { error: null };
}

export async function createPost(userId: string, data: {
  title: string;
  content: string;
  action_step?: string;
  ai_summary?: string;
  media_url?: string;
  media_type?: "image" | "video";
}) {
  const today = new Date().toISOString().split("T")[0];

  const { error } = await supabase.from("posts").insert({
    user_id: userId,
    ...data,
  });

  if (!error) {
    // Upsert progress for post creation
    const { data: existing } = await supabase
      .from("user_progress")
      .select("id, posts_created")
      .eq("user_id", userId)
      .eq("date", today)
      .maybeSingle();

    if (existing) {
      await supabase.from("user_progress").update({
        posts_created: (existing.posts_created || 0) + 1,
      }).eq("id", existing.id);
    } else {
      await supabase.from("user_progress").insert({
        user_id: userId,
        date: today,
        posts_created: 1,
      });
    }
  }

  return { error };
}
