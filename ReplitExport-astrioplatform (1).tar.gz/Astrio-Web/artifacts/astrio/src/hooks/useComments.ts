import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/lib/supabase";
import type { Database } from "@/types/database";

type Comment = Database["public"]["Tables"]["comments"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export interface CommentWithProfile extends Comment {
  profile: Profile | null;
}

export function useComments(postId: string | null) {
  const [comments, setComments] = useState<CommentWithProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const fetchComments = useCallback(async () => {
    if (!postId) return;
    setLoading(true);

    const { data } = await supabase
      .from("comments")
      .select("*")
      .eq("post_id", postId)
      .order("created_at", { ascending: true });

    if (!data) { setLoading(false); return; }

    const enriched: CommentWithProfile[] = await Promise.all(
      data.map(async (comment) => {
        const { data: profile } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", comment.user_id)
          .single();
        return { ...comment, profile: profile ?? null };
      })
    );

    setComments(enriched);
    setLoading(false);
  }, [postId]);

  useEffect(() => {
    if (!postId) return;

    fetchComments();

    // Tear down old channel
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }

    const channel = supabase
      .channel(`comments-${postId}-${Date.now()}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "comments", filter: `post_id=eq.${postId}` },
        () => { fetchComments(); }
      )
      .subscribe();

    channelRef.current = channel;

    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [postId]);

  const addComment = useCallback(async (userId: string, content: string) => {
    if (!postId || !content.trim()) return { error: new Error("Missing data") };
    setSubmitting(true);

    const { error } = await supabase
      .from("comments")
      .insert({ post_id: postId, user_id: userId, content: content.trim() });

    if (!error) {
      // Bump comments_count on the post
      const { data: post } = await supabase
        .from("posts")
        .select("comments_count")
        .eq("id", postId)
        .single();
      if (post) {
        await supabase
          .from("posts")
          .update({ comments_count: (post.comments_count ?? 0) + 1 })
          .eq("id", postId);
      }
      await fetchComments();
    }

    setSubmitting(false);
    return { error };
  }, [postId, fetchComments]);

  const deleteComment = useCallback(async (commentId: string) => {
    if (!postId) return;
    await supabase.from("comments").delete().eq("id", commentId);

    const { data: post } = await supabase
      .from("posts")
      .select("comments_count")
      .eq("id", postId)
      .single();
    if (post) {
      await supabase
        .from("posts")
        .update({ comments_count: Math.max(0, (post.comments_count ?? 1) - 1) })
        .eq("id", postId);
    }
    await fetchComments();
  }, [postId, fetchComments]);

  return { comments, loading, submitting, addComment, deleteComment, refetch: fetchComments };
}
