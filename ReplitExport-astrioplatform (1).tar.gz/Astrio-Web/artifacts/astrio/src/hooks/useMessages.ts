import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import type { Database } from "@/types/database";

type Message = Database["public"]["Tables"]["messages"]["Row"];
type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export interface Conversation {
  partnerId: string;
  partnerProfile: Profile | null;
  lastMessage: Message | null;
  unreadCount: number;
}

export function useConversations(userId?: string) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchConversations = useCallback(async () => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const { data: msgs } = await supabase
      .from("messages")
      .select("*")
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .eq("is_ai", false)
      .order("created_at", { ascending: false });

    if (!msgs) {
      setLoading(false);
      return;
    }

    const partnerMap = new Map<string, Message>();
    for (const msg of msgs) {
      const partnerId =
        msg.sender_id === userId ? msg.receiver_id : msg.sender_id;
      if (!partnerMap.has(partnerId)) partnerMap.set(partnerId, msg);
    }

    const convs: Conversation[] = await Promise.all(
      Array.from(partnerMap.entries()).map(async ([partnerId, lastMsg]) => {
        const { data: profile } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", partnerId)
          .single();
        const { count } = await supabase
          .from("messages")
          .select("*", { count: "exact", head: true })
          .eq("receiver_id", userId)
          .eq("sender_id", partnerId)
          .eq("read", false);
        return {
          partnerId,
          partnerProfile: profile ?? null,
          lastMessage: lastMsg,
          unreadCount: count ?? 0,
        };
      })
    );

    setConversations(convs);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  return { conversations, loading, refetch: fetchConversations };
}

export function useMessages(userId?: string, partnerId?: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const fetchMessages = useCallback(async () => {
    if (!userId || !partnerId) return;
    const { data } = await supabase
      .from("messages")
      .select("*")
      .or(
        `and(sender_id.eq.${userId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userId})`
      )
      .eq("is_ai", false)
      .order("created_at", { ascending: true });
    setMessages(data ?? []);
    setLoading(false);

    // Mark received messages as read in background
    supabase
      .from("messages")
      .update({ read: true })
      .eq("receiver_id", userId)
      .eq("sender_id", partnerId)
      .eq("read", false)
      .then(() => {});
  }, [userId, partnerId]);

  useEffect(() => {
    if (!userId || !partnerId) return;

    setLoading(true);
    fetchMessages();

    // Tear down any existing channel
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }

    const channelName = `messages-${userId}-${partnerId}-${Date.now()}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        (payload) => {
          const msg = payload.new as Message;
          // Only refresh if this message belongs to this conversation
          const belongs =
            (msg.sender_id === userId && msg.receiver_id === partnerId) ||
            (msg.sender_id === partnerId && msg.receiver_id === userId);
          if (belongs) fetchMessages();
        }
      )
      .subscribe();

    channelRef.current = channel;

    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, partnerId]);

  const sendMessage = async (content: string, isAi = false) => {
    if (!userId || !partnerId) return { error: new Error("No user or partner") };
    const { error } = await supabase.from("messages").insert({
      sender_id: userId,
      receiver_id: partnerId,
      content,
      is_ai: isAi,
    });
    if (!error) await fetchMessages();
    return { error };
  };

  return { messages, loading, sendMessage, refetch: fetchMessages };
}
