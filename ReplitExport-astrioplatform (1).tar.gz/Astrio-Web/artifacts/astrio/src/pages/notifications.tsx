import { useAuth } from "@/context/AuthContext";
import { useNotifications } from "@/hooks/useNotifications";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Bell, Heart, MessageSquare, Zap, Star, MessageCircle, CheckCircle2 } from "lucide-react";

export default function NotificationsPage() {
  const { user } = useAuth();
  const { notifications, loading, markAllRead, markRead } = useNotifications(user?.id);

  const getIcon = (type: string) => {
    switch (type) {
      case "like":    return <Heart className="w-5 h-5 text-red-500" />;
      case "comment": return <MessageCircle className="w-5 h-5 text-blue-400" />;
      case "message": return <MessageSquare className="w-5 h-5 text-purple-400" />;
      case "xp":      return <Zap className="w-5 h-5 text-yellow-400" />;
      case "action":  return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      default:        return <Star className="w-5 h-5 text-primary" />;
    }
  };

  const timeAgo = (iso: string) => {
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    const hrs = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    if (hrs < 24) return `${hrs}h ago`;
    return `${days}d ago`;
  };

  const hasUnread = notifications.some((n) => !n.read);

  return (
    <div className="min-h-screen flex flex-col pb-16 bg-background">
      <TopBar />
      <div className="flex-1 max-w-2xl mx-auto w-full">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-4">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Bell className="w-5 h-5" /> Notifications
          </h1>
          {hasUnread && (
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllRead}
              className="text-primary text-xs font-semibold"
              data-testid="button-mark-all-read"
            >
              Mark all read
            </Button>
          )}
        </div>

        {loading ? (
          <div className="space-y-3 px-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4 p-4 rounded-xl border border-border/30 bg-card/30 animate-pulse">
                <div className="w-10 h-10 rounded-full bg-muted shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-3.5 w-2/3 bg-muted rounded" />
                  <div className="h-3 w-full bg-muted/60 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center mt-24 px-6">
            <div className="w-16 h-16 rounded-full bg-muted/30 flex items-center justify-center mb-4">
              <Bell className="w-8 h-8 text-muted-foreground/40" />
            </div>
            <p className="font-semibold text-muted-foreground">All caught up</p>
            <p className="text-sm text-muted-foreground/60 mt-1">No notifications yet</p>
          </div>
        ) : (
          <div className="divide-y divide-border/30">
            {notifications.map((notif) => (
              <button
                key={notif.id}
                className={`w-full flex items-start gap-4 px-4 py-4 text-left transition-colors hover:bg-muted/20 ${
                  !notif.read ? "bg-primary/5" : ""
                }`}
                onClick={() => !notif.read && markRead(notif.id)}
                data-testid={`notification-${notif.id}`}
              >
                <div className="mt-0.5 w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center shrink-0">
                  {getIcon(notif.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold leading-snug">{notif.title}</p>
                  <p className="text-sm text-muted-foreground mt-0.5 leading-snug">{notif.body}</p>
                  <p className="text-[11px] text-muted-foreground/60 mt-1.5 font-medium">{timeAgo(notif.created_at)}</p>
                </div>
                {!notif.read && (
                  <div className="w-2.5 h-2.5 rounded-full bg-primary mt-2 shrink-0 shadow-[0_0_6px_rgba(139,92,246,0.6)]" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
