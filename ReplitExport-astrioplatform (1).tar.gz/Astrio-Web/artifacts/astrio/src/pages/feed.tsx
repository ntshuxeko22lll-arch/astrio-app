import { useState, useCallback } from "react";
import { usePosts } from "@/hooks/usePosts";
import { useAuth } from "@/context/AuthContext";
import { TopBar } from "@/components/TopBar";
import { CommentSheet } from "@/components/CommentSheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Heart, MessageCircle, Sparkles, CheckCircle2,
  CheckCheck, Zap, Link as LinkIcon,
} from "lucide-react";
import { toggleLike, completeAction } from "@/hooks/usePosts";
import { useToast } from "@/hooks/use-toast";

export default function FeedPage() {
  const { user } = useAuth();
  const { posts, loading, refetch } = usePosts(user?.id);
  const { toast } = useToast();

  const [processingLike, setProcessingLike]     = useState<string | null>(null);
  const [processingAction, setProcessingAction] = useState<string | null>(null);

  // Comments sheet state
  const [commentPostId,    setCommentPostId]    = useState<string | null>(null);
  const [commentPostTitle, setCommentPostTitle] = useState<string | undefined>();
  const [commentSheetOpen, setCommentSheetOpen] = useState(false);

  // Live comment-count overrides so counts update without full refetch
  const [countOverrides, setCountOverrides] = useState<Record<string, number>>({});

  const openComments = (postId: string, title: string) => {
    setCommentPostId(postId);
    setCommentPostTitle(title);
    setCommentSheetOpen(true);
  };

  const handleCountChange = useCallback((postId: string, count: number) => {
    setCountOverrides((prev) => ({ ...prev, [postId]: count }));
  }, []);

  const handleLike = async (postId: string, liked: boolean) => {
    if (!user || processingLike === postId) return;
    setProcessingLike(postId);
    try {
      await toggleLike(postId, user.id, liked);
      await refetch();
    } catch {
      toast({ title: "Error liking post", variant: "destructive" });
    } finally {
      setProcessingLike(null);
    }
  };

  const handleAction = async (postId: string) => {
    if (!user || processingAction === postId) return;
    setProcessingAction(postId);
    try {
      const { error } = await completeAction(postId, user.id);
      if (error) throw error;
      toast({ title: "+50 XP Earned!", description: "Action completed. Keep the momentum going." });
      await refetch();
    } catch (e: any) {
      if (e?.code === "23505") {
        toast({ title: "Already completed", description: "You already did this action." });
      } else {
        toast({ title: "Error", description: "Could not complete action.", variant: "destructive" });
      }
    } finally {
      setProcessingAction(null);
    }
  };

  const handleShare = async (postId: string, title: string) => {
    const url = `${window.location.origin}/post/${postId}`;
    try {
      if (navigator.share) {
        await navigator.share({ title, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast({ title: "Link copied", description: "Post link copied to clipboard." });
      }
    } catch {
      // user dismissed share sheet — no-op
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <TopBar />
        <div className="p-4 space-y-4 max-w-2xl mx-auto pb-20">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="overflow-hidden border-border/50 bg-card/40">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted animate-pulse" />
                  <div className="space-y-2 flex-1">
                    <div className="h-3 w-28 bg-muted rounded animate-pulse" />
                    <div className="h-2.5 w-16 bg-muted/60 rounded animate-pulse" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 pb-4">
                <div className="h-5 w-3/4 bg-muted rounded animate-pulse" />
                <div className="h-3 w-full bg-muted/60 rounded animate-pulse" />
                <div className="h-3 w-5/6 bg-muted/60 rounded animate-pulse" />
                <div className="h-3 w-2/3 bg-muted/60 rounded animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopBar />

      <div className="flex-1 py-4 px-3 space-y-5 max-w-2xl mx-auto w-full pb-24">
        {posts.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center mt-20 px-6">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Zap className="w-8 h-8 text-primary" />
            </div>
            <h3 className="font-bold text-lg mb-2">No posts yet</h3>
            <p className="text-sm text-muted-foreground">
              Be the first to share your progress and inspire others.
            </p>
          </div>
        ) : (
          posts.map((post) => {
            const commentCount = countOverrides[post.id] ?? post.comments_count;
            return (
              <Card
                key={post.id}
                className="overflow-hidden border-border/40 bg-card/60 backdrop-blur-sm shadow-lg shadow-black/20"
                data-testid={`post-card-${post.id}`}
              >
                {/* Author */}
                <CardHeader className="p-4 pb-3 flex flex-row items-center gap-3">
                  <Avatar className="h-10 w-10 border border-primary/20 shrink-0">
                    <AvatarImage src={post.profile?.avatar_url ?? ""} />
                    <AvatarFallback className="bg-primary/10 text-primary text-sm font-bold">
                      {post.profile?.username?.[0]?.toUpperCase() ?? "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="font-semibold text-sm leading-none truncate">
                      {post.profile?.username ?? "Unknown"}
                    </span>
                    <span className="text-xs text-muted-foreground mt-1">
                      Lvl {post.profile?.level ?? 1} ·{" "}
                      {new Date(post.created_at).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                </CardHeader>

                {/* Body */}
                <CardContent className="px-4 pb-4 space-y-3">
                  <h3 className="text-base font-bold leading-snug">{post.title}</h3>
                  <p className="text-sm text-foreground/80 whitespace-pre-wrap leading-relaxed">
                    {post.content}
                  </p>

                  {/* Media */}
                  {post.media_url && (
                    <div className="rounded-xl overflow-hidden border border-border/30 mt-1">
                      {post.media_type === "video" ? (
                        <video
                          src={post.media_url}
                          controls
                          muted
                          playsInline
                          preload="metadata"
                          className="w-full max-h-[400px] bg-black object-contain"
                          data-testid={`post-video-${post.id}`}
                        />
                      ) : (
                        <img
                          src={post.media_url}
                          alt="Post media"
                          className="w-full max-h-[400px] object-cover"
                          loading="lazy"
                          data-testid={`post-image-${post.id}`}
                        />
                      )}
                    </div>
                  )}

                  {/* AI + Action block */}
                  {(post.ai_summary || post.action_step) && (
                    <div className="bg-gradient-to-br from-primary/8 to-primary/3 border border-primary/20 rounded-xl p-4 space-y-3 relative overflow-hidden">
                      <Sparkles className="absolute top-3 right-3 w-10 h-10 text-primary/8 pointer-events-none" />

                      {post.ai_summary && (
                        <div>
                          <p className="text-[10px] font-bold text-primary uppercase tracking-widest mb-1.5 flex items-center gap-1">
                            <Sparkles className="w-3 h-3" /> AI Insight
                          </p>
                          <p className="text-sm text-primary/90 italic leading-relaxed">
                            {post.ai_summary}
                          </p>
                        </div>
                      )}

                      {post.action_step && (
                        <div className={post.ai_summary ? "pt-3 border-t border-primary/15" : ""}>
                          <p className="text-[10px] font-bold text-accent-foreground uppercase tracking-widest mb-1.5 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-green-400" /> Action Step
                          </p>
                          <p className="text-sm font-medium leading-snug mb-3">
                            {post.action_step}
                          </p>
                          <Button
                            onClick={() => handleAction(post.id)}
                            disabled={post.action_done || processingAction === post.id}
                            size="sm"
                            className={`w-full h-9 text-xs font-semibold rounded-lg transition-all ${
                              post.action_done
                                ? "bg-muted text-muted-foreground cursor-default"
                                : "bg-gradient-to-r from-primary to-violet-600 hover:opacity-90 shadow-md shadow-primary/20"
                            }`}
                            data-testid={`button-action-${post.id}`}
                          >
                            {processingAction === post.id ? (
                              "Processing..."
                            ) : post.action_done ? (
                              <span className="flex items-center gap-1.5">
                                <CheckCheck className="w-4 h-4" /> Completed
                              </span>
                            ) : (
                              <span className="flex items-center gap-1.5">
                                <Zap className="w-4 h-4" /> I Did This · +50 XP
                              </span>
                            )}
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>

                {/* Footer actions */}
                <CardFooter className="px-4 py-3 border-t border-border/30 flex items-center gap-5 text-muted-foreground bg-muted/5">
                  {/* Like */}
                  <button
                    onClick={() => handleLike(post.id, post.liked)}
                    disabled={processingLike === post.id}
                    className={`flex items-center gap-1.5 text-sm transition-all ${
                      post.liked ? "text-red-500" : "hover:text-red-400"
                    }`}
                    data-testid={`button-like-${post.id}`}
                  >
                    <Heart
                      className={`w-5 h-5 transition-transform ${
                        post.liked ? "fill-current scale-110" : ""
                      }`}
                    />
                    <span className="font-medium tabular-nums">{post.likes_count}</span>
                  </button>

                  {/* Comment */}
                  <button
                    onClick={() => openComments(post.id, post.title)}
                    className="flex items-center gap-1.5 text-sm hover:text-primary transition-colors"
                    data-testid={`button-comment-${post.id}`}
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span className="font-medium tabular-nums">{commentCount}</span>
                  </button>

                  {/* Share */}
                  <button
                    onClick={() => handleShare(post.id, post.title)}
                    className="flex items-center gap-1.5 text-sm hover:text-foreground transition-colors ml-auto"
                    data-testid={`button-share-${post.id}`}
                  >
                    <LinkIcon className="w-4 h-4" />
                  </button>
                </CardFooter>
              </Card>
            );
          })
        )}
      </div>

      {/* Comments slide-up sheet */}
      <CommentSheet
        postId={commentPostId}
        postTitle={commentPostTitle}
        open={commentSheetOpen}
        onClose={() => setCommentSheetOpen(false)}
        onCountChange={handleCountChange}
      />
    </div>
  );
}
