import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { supabase } from "@/lib/supabase";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, LogOut, Camera } from "lucide-react";
import { useLocation } from "wouter";

export default function SettingsPage() {
  const { user, signOut } = useAuth();
  const { profile, updateProfile } = useProfile(user?.id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [goal, setGoal] = useState("");
  const [goals, setGoals] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (profile) {
      setUsername(profile.username || "");
      setBio(profile.bio || "");
      setGoal(profile.goal || "");
    }
  }, [profile]);

  useEffect(() => {
    supabase.from("goals").select("*").then(({ data }) => {
      if (data) setGoals(data);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const { error } = await updateProfile({ username, bio, goal });
    setSaving(false);
    if (error) {
      toast({ variant: "destructive", title: "Error saving profile", description: error.message });
    } else {
      toast({ title: "Profile updated successfully!" });
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0] || !user) return;
    
    setUploading(true);
    const file = e.target.files[0];
    const fileExt = file.name.split('.').pop();
    const filePath = `${user.id}/${Math.random()}.${fileExt}`;

    try {
      const { error: uploadError } = await supabase.storage.from("avatars").upload(filePath, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from("avatars").getPublicUrl(filePath);
      
      await updateProfile({ avatar_url: publicUrl });
      toast({ title: "Avatar updated!" });
    } catch (error: any) {
      toast({ variant: "destructive", title: "Upload failed", description: error.message });
    } finally {
      setUploading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setLocation("/auth");
  };

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <TopBar />
      <div className="flex-1 p-4 max-w-2xl mx-auto w-full space-y-8 mt-4">
        
        <h1 className="text-2xl font-bold">Account Settings</h1>

        <div className="flex flex-col items-center space-y-4 mb-8">
          <div className="relative">
            <Avatar className="h-24 w-24 border-4 border-background ring-2 ring-primary">
              <AvatarImage src={profile?.avatar_url || ""} />
              <AvatarFallback className="text-2xl">{username?.[0]?.toUpperCase()}</AvatarFallback>
            </Avatar>
            <label htmlFor="avatar-upload" className="absolute bottom-0 right-0 p-2 bg-primary text-primary-foreground rounded-full cursor-pointer hover:bg-primary/90 transition-colors shadow-lg">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
            </label>
            <Input id="avatar-upload" type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
          </div>
        </div>

        <div className="space-y-4 bg-card/50 p-6 rounded-xl border border-border/50">
          <div className="space-y-2">
            <Label>Username</Label>
            <Input value={username} onChange={e => setUsername(e.target.value)} className="bg-background" />
          </div>
          
          <div className="space-y-2">
            <Label>Bio</Label>
            <Textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Tell us about yourself..." className="bg-background resize-none" />
          </div>

          <div className="space-y-2">
            <Label>Primary Goal</Label>
            <Select value={goal} onValueChange={setGoal}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select your main focus" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fitness">Fitness & Health</SelectItem>
                <SelectItem value="business">Business & Career</SelectItem>
                <SelectItem value="learning">Learning & Skills</SelectItem>
                <SelectItem value="productivity">Productivity</SelectItem>
                {goals.map(g => (
                   <SelectItem key={g.id} value={g.name.toLowerCase()}>{g.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full mt-4">
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : "Save Changes"}
          </Button>
        </div>

        <div className="pt-8">
          <Button variant="outline" className="w-full text-destructive hover:bg-destructive hover:text-destructive-foreground border-destructive/50" onClick={handleSignOut}>
            <LogOut className="w-4 h-4 mr-2" /> Sign Out
          </Button>
        </div>

      </div>
    </div>
  );
}
