import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { generateAIResponse, AIMode } from "@/services/aiService";
import { Bot, Send, Zap, Target, Wrench, ArrowLeft } from "lucide-react";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/context/AuthContext";
import { Link } from "wouter";

interface ChatMessage {
  id: string;
  role: "user" | "ai";
  content: string;
  actionStep?: string;
  timestamp: Date;
}

const MODE_CONFIG = {
  coach: {
    icon: Zap,
    label: "Coach",
    color: "text-primary",
    bg: "bg-primary",
    description: "Personal motivation & strategy",
    prompts: [
      "I'm feeling unmotivated today",
      "Help me focus on my top priority",
      "How do I stay consistent?",
    ],
  },
  daily_action: {
    icon: Target,
    label: "Daily Action",
    color: "text-green-400",
    bg: "bg-green-500",
    description: "Get a specific task for your goal",
    prompts: [
      "What should I do today?",
      "Give me a 10-minute action",
      "I need a challenge for this week",
    ],
  },
  problem_solver: {
    icon: Wrench,
    label: "Problem Solver",
    color: "text-blue-400",
    bg: "bg-blue-500",
    description: "Overcome obstacles & blockers",
    prompts: [
      "I'm stuck and don't know what to do",
      "Help me brainstorm solutions",
      "How do I overcome this block?",
    ],
  },
};

export default function AIPage() {
  const { user } = useAuth();
  const { profile } = useProfile(user?.id);
  const [mode, setMode] = useState<AIMode>("coach");
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [thinking, setThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || thinking) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: text,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setQuery("");
    setThinking(true);

    // Simulate a brief thinking delay for natural feel
    await new Promise((res) => setTimeout(res, 700 + Math.random() * 600));

    const response = generateAIResponse(mode, text, profile?.goal ?? undefined);

    const aiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: "ai",
      content: response.message,
      actionStep: response.actionStep,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, aiMsg]);
    setThinking(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(query);
  };

  const handlePrompt = (prompt: string) => {
    sendMessage(prompt);
  };

  const handleModeChange = (newMode: AIMode) => {
    setMode(newMode);
    setMessages([]);
  };

  const config = MODE_CONFIG[mode];
  const ModeIcon = config.icon;

  return (
    <div className="flex flex-col h-[100dvh] pb-16 bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/90 backdrop-blur-xl border-b border-border h-14 flex items-center px-4 gap-3">
        <div className="flex items-center gap-2 flex-1">
          <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center ring-1 ring-primary/20">
            <Bot className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="font-bold text-sm leading-none">Astrio Intelligence</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{config.description}</p>
          </div>
        </div>
      </div>

      {/* Mode selector */}
      <div className="flex gap-2 px-4 py-3 border-b border-border/50 bg-background/60 overflow-x-auto no-scrollbar">
        {(Object.entries(MODE_CONFIG) as [AIMode, typeof MODE_CONFIG[AIMode]][]).map(([key, cfg]) => {
          const Icon = cfg.icon;
          const isActive = mode === key;
          return (
            <button
              key={key}
              onClick={() => handleModeChange(key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all shrink-0 ${
                isActive
                  ? `${cfg.bg} text-white shadow-md`
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              }`}
              data-testid={`button-mode-${key}`}
            >
              <Icon className="w-3.5 h-3.5" />
              {cfg.label}
            </button>
          );
        })}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 && !thinking && (
          <div className="flex flex-col items-center justify-center h-full text-center py-8 space-y-6">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center ring-2 ring-primary/20 shadow-[0_0_30px_rgba(139,92,246,0.2)]">
              <ModeIcon className={`w-8 h-8 ${config.color}`} />
            </div>
            <div>
              <h2 className="font-bold text-lg mb-1">{config.label} Mode</h2>
              <p className="text-sm text-muted-foreground">{config.description}</p>
            </div>
            <div className="w-full max-w-sm space-y-2">
              <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-3">Try asking...</p>
              {config.prompts.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handlePrompt(prompt)}
                  className="w-full text-left text-sm p-3.5 rounded-xl border border-border/50 bg-card/50 hover:bg-primary/5 hover:border-primary/30 transition-all"
                  data-testid={`button-prompt-${i}`}
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "ai" && (
              <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center mr-2 mt-1 shrink-0 ring-1 ring-primary/20">
                <Bot className="w-3.5 h-3.5 text-primary" />
              </div>
            )}
            <div className={`max-w-[85%] space-y-2 ${msg.role === "user" ? "" : ""}`}>
              <div
                className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-sm"
                    : "bg-card border border-border/50 text-foreground rounded-bl-sm"
                }`}
              >
                {msg.content}
              </div>
              {msg.actionStep && (
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-xl p-3">
                  <p className="text-[10px] font-bold text-primary uppercase tracking-widest mb-1.5">Recommended Action</p>
                  <p className="text-sm font-medium">{msg.actionStep}</p>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground px-1">
                {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}

        {/* Thinking indicator */}
        {thinking && (
          <div className="flex justify-start items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center shrink-0 ring-1 ring-primary/20">
              <Bot className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="bg-card border border-border/50 rounded-2xl rounded-bl-sm px-4 py-3">
              <div className="flex gap-1 items-center h-4">
                <div className="w-1.5 h-1.5 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-1.5 h-1.5 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-1.5 h-1.5 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-3 bg-background/90 backdrop-blur-xl border-t border-border">
        <form onSubmit={handleSubmit} className="flex gap-2 items-center">
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask Astrio AI anything..."
            className="bg-muted/50 border-border/50 rounded-full px-4 h-10 text-sm focus-visible:ring-primary/50"
            disabled={thinking}
            data-testid="input-ai-message"
          />
          <Button
            type="submit"
            size="icon"
            className="rounded-full h-10 w-10 shrink-0 bg-primary hover:bg-primary/90"
            disabled={!query.trim() || thinking}
            data-testid="button-ai-send"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
