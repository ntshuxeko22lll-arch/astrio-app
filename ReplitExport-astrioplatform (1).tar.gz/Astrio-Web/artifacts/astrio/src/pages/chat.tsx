import { useState, useEffect, useRef, useCallback } from "react";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Search, ArrowLeft, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Profile {
  id: string;
  username: string;
  avatar_url: string | null;
  level: number;
}

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  read: boolean;
}

interface Conversation {
  partner: Profile;
  lastMessage: string;
  lastTime: string;
  unread: number;
}

export default function ChatPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activePartner, setActivePartner] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const [sendingMsg, setSendingMsg] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Load conversations
  const loadConversations = useCallback(async () => {
    if (!user) return;
    const { data: msgs } = await supabase
      .from("messages")
      .select("*")
      .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
      .eq("is_ai", false)
      .order("created_at", { ascending: false });

    if (!msgs) return;

    const partnerMap = new Map<string, Message>();
    for (const msg of msgs) {
      const partnerId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
      if (!partnerMap.has(partnerId)) partnerMap.set(partnerId, msg);
    }

    const convs: Conversation[] = [];
    for (const [partnerId, lastMsg] of partnerMap.entries()) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("id, username, avatar_url, level")
        .eq("id", partnerId)
        .single();

      if (!profile) continue;

      const { count } = await supabase
        .from("messages")
        .select("*", { count: "exact", head: true })
        .eq("receiver_id", user.id)
        .eq("sender_id", partnerId)
        .eq("read", false);

      convs.push({
        partner: profile,
        lastMessage: lastMsg.content,
        lastTime: lastMsg.created_at,
        unread: count ?? 0,
      });
    }

    setConversations(convs);
  }, [user]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Load messages for active partner + poll
  const loadMessages = useCallback(async () => {
    if (!user || !activePartner) return;
    const { data } = await supabase
      .from("messages")
      .select("*")
      .or(
        `and(sender_id.eq.${user.id},receiver_id.eq.${activePartner.id}),and(sender_id.eq.${activePartner.id},receiver_id.eq.${user.id})`
      )
      .eq("is_ai", false)
      .order("created_at", { ascending: true });

    setMessages(data ?? []);

    // Mark received messages as read
    await supabase
      .from("messages")
      .update({ read: true })
      .eq("receiver_id", user.id)
      .eq("sender_id", activePartner.id)
      .eq("read", false);
  }, [user, activePartner]);

  useEffect(() => {
    if (!activePartner) return;
    loadMessages();
    pollRef.current = setInterval(loadMessages, 4000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [activePartner, loadMessages]);

  // Search users
  useEffect(() => {
    if (!searchQuery.trim() || !user) {
      setSearchResults([]);
      return;
    }
    const timeout = setTimeout(async () => {
      setSearching(true);
      const { data } = await supabase
        .from("profiles")
        .select("id, username, avatar_url, level")
        .ilike("username", `%${searchQuery}%`)
        .neq("id", user.id)
        .limit(10);
      setSearchResults((data as Profile[]) ?? []);
      setSearching(false);
    }, 300);
    return () => clearTimeout(timeout);
  }, [searchQuery, user]);

  const openConversation = (partner: Profile) => {
    setActivePartner(partner);
    setShowSearch(false);
    setSearchQuery("");
    setSearchResults([]);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !activePartner) return;

    setSendingMsg(true);
    const content = newMessage.trim();
    setNewMessage("");

    const { error } = await supabase.from("messages").insert({
      sender_id: user.id,
      receiver_id: activePartner.id,
      content,
      is_ai: false,
    });

    if (error) {
      toast({ variant: "destructive", title: "Failed to send message" });
      setNewMessage(content);
    } else {
      await loadMessages();
      await loadConversations();

      // Create notification for receiver
      await supabase.from("notifications").insert({
        user_id: activePartner.id,
        type: "message",
        title: "New message",
        body: `You have a new message from a user.`,
      });
    }
    setSendingMsg(false);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return "now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m`;
    if (diff < 86400000) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    return d.toLocaleDateString();
  };

  return (
    <div className="flex h-[100dvh] pb-16 flex-col md:flex-row">
      {/* Sidebar */}
      <div className={`${activePartner ? "hidden md:flex" : "flex"} flex-col w-full md:w-80 border-r border-border bg-card/20`}>
        {/* Header */}
        <div className="h-14 border-b border-border px-4 flex items-center justify-between sticky top-0 bg-background/90 backdrop-blur-xl z-10">
          <span className="font-bold text-lg">Messages</span>
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
            data-testid="button-search-users"
          >
            <Search className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Search */}
        {showSearch && (
          <div className="p-3 border-b border-border bg-background/60">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users..."
                className="pl-9 bg-muted/50 border-border/50 rounded-full h-9 text-sm"
                autoFocus
                data-testid="input-search-users"
              />
            </div>
            {searchQuery.trim() && (
              <div className="mt-2 space-y-1">
                {searching && <p className="text-xs text-muted-foreground text-center py-2">Searching...</p>}
                {!searching && searchResults.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-2">No users found</p>
                )}
                {searchResults.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => openConversation(u)}
                    className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors text-left"
                    data-testid={`button-user-${u.id}`}
                  >
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={u.avatar_url || ""} />
                      <AvatarFallback className="text-xs">{u.username[0]?.toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-sm">{u.username}</div>
                      <div className="text-xs text-muted-foreground">Level {u.level}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 && !showSearch && (
            <div className="flex flex-col items-center justify-center h-full text-center px-6 py-12">
              <MessageSquare className="w-12 h-12 text-muted-foreground/30 mb-4" />
              <p className="text-sm font-medium text-muted-foreground">No conversations yet</p>
              <p className="text-xs text-muted-foreground mt-1">Tap the search icon to find people</p>
            </div>
          )}
          {conversations.map((conv) => (
            <button
              key={conv.partner.id}
              onClick={() => openConversation(conv.partner)}
              className={`w-full p-4 flex items-center gap-3 hover:bg-muted/30 transition-colors text-left border-b border-border/30 ${activePartner?.id === conv.partner.id ? "bg-primary/10" : ""}`}
              data-testid={`conversation-${conv.partner.id}`}
            >
              <Avatar className="h-12 w-12 shrink-0">
                <AvatarImage src={conv.partner.avatar_url || ""} />
                <AvatarFallback>{conv.partner.username[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sm truncate">{conv.partner.username}</span>
                  <span className="text-[10px] text-muted-foreground shrink-0 ml-2">{formatTime(conv.lastTime)}</span>
                </div>
                <div className="flex items-center justify-between mt-0.5">
                  <p className="text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                  {conv.unread > 0 && (
                    <span className="ml-2 bg-primary text-primary-foreground text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center shrink-0">
                      {conv.unread}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Message thread */}
      <div className={`${activePartner ? "flex" : "hidden md:flex"} flex-1 flex-col h-full`}>
        {!activePartner ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
            <MessageSquare className="w-16 h-16 text-muted-foreground/20 mb-4" />
            <p className="text-muted-foreground">Select a conversation or search for someone to chat with</p>
          </div>
        ) : (
          <>
            {/* Thread header */}
            <div className="h-14 border-b border-border bg-background/90 backdrop-blur-xl px-4 flex items-center gap-3 sticky top-0 z-10">
              <button
                onClick={() => setActivePartner(null)}
                className="md:hidden p-1.5 -ml-1.5 hover:bg-muted rounded-full transition-colors"
                data-testid="button-back-chat"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <Avatar className="h-9 w-9">
                <AvatarImage src={activePartner.avatar_url || ""} />
                <AvatarFallback>{activePartner.username[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-sm leading-none">{activePartner.username}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Level {activePartner.level}</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center py-12">
                  <p className="text-sm text-muted-foreground">No messages yet. Say hello!</p>
                </div>
              )}
              {messages.map((msg) => {
                const isMe = msg.sender_id === user?.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-sm ${
                        isMe
                          ? "bg-primary text-primary-foreground rounded-br-sm"
                          : "bg-card border border-border/50 text-foreground rounded-bl-sm"
                      }`}
                    >
                      <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                      <span className={`text-[10px] mt-1 block ${isMe ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                        {formatTime(msg.created_at)}
                      </span>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 bg-background/90 backdrop-blur-xl border-t border-border">
              <form onSubmit={handleSend} className="flex gap-2 items-center">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={`Message ${activePartner.username}...`}
                  className="bg-muted/50 border-border/50 rounded-full px-4 h-10 text-sm focus-visible:ring-primary/50"
                  data-testid="input-message"
                />
                <Button
                  type="submit"
                  size="icon"
                  className="rounded-full h-10 w-10 shrink-0 bg-primary hover:bg-primary/90"
                  disabled={!newMessage.trim() || sendingMsg}
                  data-testid="button-send-message"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
