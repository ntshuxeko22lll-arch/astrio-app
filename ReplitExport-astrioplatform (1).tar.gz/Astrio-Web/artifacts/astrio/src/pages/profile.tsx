import { useAuth } from "@/context/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { usePosts } from "@/hooks/usePosts";
import { TopBar } from "@/components/TopBar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Flame, Zap, Settings, Activity } from "lucide-react";
import { Link } from "wouter";

export default function ProfilePage() {
  const { user } = useAuth();
  const { profile, loading: profileLoading } = useProfile(user?.id);
  const { posts, loading: postsLoading } = usePosts();
  
  const userPosts = posts.filter(p => p.user_id === user?.id);

  if (profileLoading) return <div className="p-4 text-center mt-20">Loading profile...</div>;

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <TopBar />
      <div className="flex-1 p-4 max-w-2xl mx-auto w-full space-y-6">
        
        <div className="flex justify-end">
          <Link href="/settings">
            <Button variant="ghost" size="icon" className="rounded-full">
              <Settings className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="flex flex-col items-center space-y-4 text-center">
          <Avatar className="h-24 w-24 border-4 border-background ring-2 ring-primary shadow-xl">
            <AvatarImage src={profile?.avatar_url || ""} />
            <AvatarFallback className="text-2xl bg-primary/20 text-primary">{profile?.username?.[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold">{profile?.username}</h1>
            <p className="text-muted-foreground">{profile?.bio || "No bio yet."}</p>
          </div>
          
          <div className="flex gap-2">
            <div className="bg-primary/10 border border-primary/20 rounded-full px-4 py-1 text-xs font-semibold text-primary">
              Lvl {profile?.level || 1}
            </div>
            {profile?.goal && (
              <div className="bg-accent/10 border border-accent/20 rounded-full px-4 py-1 text-xs font-semibold text-accent">
                {profile.goal}
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          <Link href="/progress" className="bg-card/50 border border-border/50 rounded-xl p-3 hover:bg-card/80 transition-colors">
            <Flame className="w-5 h-5 mx-auto mb-1 text-orange-500" />
            <div className="font-bold text-lg">{profile?.streak || 0}</div>
            <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Streak</div>
          </Link>
          <Link href="/progress" className="bg-card/50 border border-border/50 rounded-xl p-3 hover:bg-card/80 transition-colors">
            <Zap className="w-5 h-5 mx-auto mb-1 text-yellow-400" />
            <div className="font-bold text-lg">{profile?.completed_actions || 0}</div>
            <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Actions</div>
          </Link>
          <Link href="/progress" className="bg-card/50 border border-border/50 rounded-xl p-3 hover:bg-card/80 transition-colors">
            <Activity className="w-5 h-5 mx-auto mb-1 text-primary" />
            <div className="font-bold text-lg">{userPosts.length}</div>
            <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Posts</div>
          </Link>
        </div>

        <div className="pt-6">
          <h2 className="text-xl font-bold mb-4">Recent Posts</h2>
          <div className="space-y-4">
            {postsLoading ? (
              <p className="text-muted-foreground text-center">Loading posts...</p>
            ) : userPosts.length === 0 ? (
              <p className="text-center text-muted-foreground bg-card/30 p-8 rounded-xl border border-border/50">No posts yet.</p>
            ) : (
              userPosts.map(post => (
                <Card key={post.id} className="bg-card/50 border-border/50">
                  <CardContent className="p-4">
                    <h3 className="font-bold mb-2">{post.title}</h3>
                    <p className="text-sm text-foreground/80 line-clamp-3">{post.content}</p>
                    <div className="text-xs text-muted-foreground mt-3 flex justify-between">
                      <span>{new Date(post.created_at).toLocaleDateString()}</span>
                      <span>{post.likes_count} likes</span>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
