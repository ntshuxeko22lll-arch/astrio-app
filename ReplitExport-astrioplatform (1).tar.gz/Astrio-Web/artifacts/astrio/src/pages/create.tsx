import { useState, useRef } from "react";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/lib/supabase";
import { generatePostSummary } from "@/services/aiService";
import { createPost } from "@/hooks/usePosts";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2, Image as ImageIcon, Video, X, Sparkles, ArrowLeft,
  CheckCircle2, AlertCircle
} from "lucide-react";
import { Link } from "wouter";

const MAX_IMAGE_SIZE = 10 * 1024 * 1024;  // 10 MB
const MAX_VIDEO_SIZE = 50 * 1024 * 1024;  // 50 MB

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export default function CreatePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [actionStep, setActionStep] = useState("");
  const [aiSummary, setAiSummary] = useState("");

  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreviewUrl, setMediaPreviewUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video" | null>(null);
  const [mediaError, setMediaError] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const clearMedia = () => {
    if (mediaPreviewUrl) URL.revokeObjectURL(mediaPreviewUrl);
    setMediaFile(null);
    setMediaPreviewUrl(null);
    setMediaType(null);
    setMediaError(null);
    if (imageInputRef.current) imageInputRef.current.value = "";
    if (videoInputRef.current) videoInputRef.current.value = "";
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMediaError(null);

    if (!file.type.startsWith("image/")) {
      setMediaError("Please select an image file (JPG, PNG, GIF, WebP).");
      return;
    }
    if (file.size > MAX_IMAGE_SIZE) {
      setMediaError(`Image too large (${formatBytes(file.size)}). Max is 10 MB.`);
      return;
    }
    clearMedia();
    setMediaFile(file);
    setMediaType("image");
    setMediaPreviewUrl(URL.createObjectURL(file));
  };

  const handleVideoPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMediaError(null);

    if (!file.type.startsWith("video/")) {
      setMediaError("Please select a video file (MP4, MOV, WebM).");
      return;
    }
    if (file.size > MAX_VIDEO_SIZE) {
      setMediaError(`Video too large (${formatBytes(file.size)}). Max is 50 MB.`);
      return;
    }
    clearMedia();
    setMediaFile(file);
    setMediaType("video");
    setMediaPreviewUrl(URL.createObjectURL(file));
  };

  const handleGenerateSummary = () => {
    if (!content.trim()) {
      toast({ variant: "destructive", title: "Write your content first" });
      return;
    }
    const summary = generatePostSummary(title, content);
    setAiSummary(summary);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!title.trim()) { toast({ variant: "destructive", title: "Title is required" }); return; }
    if (!content.trim()) { toast({ variant: "destructive", title: "Content is required" }); return; }

    setLoading(true);
    setUploadProgress(0);

    try {
      let media_url: string | undefined;
      let upload_type: "image" | "video" | undefined;

      if (mediaFile && mediaType) {
        const ext = mediaFile.name.split(".").pop()?.toLowerCase() ?? "bin";
        const filePath = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

        setUploadProgress(15);
        const { error: uploadError } = await supabase.storage
          .from("post-media")
          .upload(filePath, mediaFile, {
            contentType: mediaFile.type,
            upsert: false,
          });
        if (uploadError) throw uploadError;
        setUploadProgress(75);

        const { data: urlData } = supabase.storage
          .from("post-media")
          .getPublicUrl(filePath);

        media_url = urlData.publicUrl;
        upload_type = mediaType;
      }

      setUploadProgress(90);

      const finalSummary = aiSummary.trim() || generatePostSummary(title, content);

      const { error } = await createPost(user.id, {
        title: title.trim(),
        content: content.trim(),
        action_step: actionStep.trim() || undefined,
        ai_summary: finalSummary,
        media_url,
        media_type: upload_type,
      });

      if (error) throw error;

      setUploadProgress(100);
      toast({ title: "Published!", description: "Your post is live in the feed." });
      setLocation("/feed");
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to publish", description: err.message });
    } finally {
      setLoading(false);
      setUploadProgress(0);
    }
  };

  const canPublish = !loading && title.trim().length > 0 && content.trim().length > 0;

  return (
    <div className="min-h-screen flex flex-col bg-background pb-20">
      {/* Top bar */}
      <div className="sticky top-0 z-40 bg-background/90 backdrop-blur-xl border-b border-border h-14 flex items-center px-4 gap-3">
        <Link href="/feed">
          <button className="p-1.5 hover:bg-muted rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
        </Link>
        <span className="font-bold text-base flex-1">New Post</span>
        <Button
          onClick={handleSubmit}
          disabled={!canPublish}
          className="h-8 px-5 text-sm rounded-full bg-primary hover:bg-primary/90 font-semibold shadow-md shadow-primary/25"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Publish"}
        </Button>
      </div>

      <div className="flex-1 p-4 max-w-2xl mx-auto w-full space-y-5 mt-1">

        {/* Title */}
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Title <span className="text-destructive">*</span>
          </Label>
          <Input
            placeholder="What are you working on?"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-card/50 border-border/50 text-base h-11 focus-visible:ring-primary/50"
          />
        </div>

        {/* Content */}
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Content <span className="text-destructive">*</span>
          </Label>
          <Textarea
            placeholder="Share your progress, insight, or challenge..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[130px] bg-card/50 border-border/50 resize-none text-sm leading-relaxed focus-visible:ring-primary/50"
          />
        </div>

        {/* AI Summary */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              AI Summary
            </Label>
            <button
              type="button"
              onClick={handleGenerateSummary}
              disabled={!content.trim()}
              className="flex items-center gap-1 text-xs text-primary font-semibold hover:opacity-80 transition-opacity disabled:opacity-30"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Auto-generate
            </button>
          </div>
          <Textarea
            placeholder="AI will generate a smart summary of your post..."
            value={aiSummary}
            onChange={(e) => setAiSummary(e.target.value)}
            className="min-h-[70px] bg-primary/5 border-primary/20 text-sm resize-none focus-visible:ring-primary/40"
          />
        </div>

        {/* Action Step */}
        <div className="space-y-1.5">
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Action Step{" "}
            <span className="text-muted-foreground/50 normal-case font-normal tracking-normal">
              — optional, readers earn +50 XP completing it
            </span>
          </Label>
          <Input
            placeholder='e.g. "Do 20 pushups right now and report back"'
            value={actionStep}
            onChange={(e) => setActionStep(e.target.value)}
            className="bg-card/50 border-border/50 text-sm h-11 focus-visible:ring-primary/50"
          />
        </div>

        {/* Media */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Media
          </Label>

          {/* Media error */}
          {mediaError && (
            <div className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{mediaError}</span>
            </div>
          )}

          {!mediaFile ? (
            /* Pick buttons */
            <div className="grid grid-cols-2 gap-3">
              {/* Image picker */}
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-dashed border-border/50 hover:border-primary/40 hover:bg-primary/5 transition-all group"
              >
                <div className="w-12 h-12 rounded-full bg-muted/60 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
                  <ImageIcon className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold">Photo</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">JPG · PNG · GIF · WebP</p>
                  <p className="text-[11px] text-muted-foreground">Up to 10 MB</p>
                </div>
              </button>

              {/* Video picker */}
              <button
                type="button"
                onClick={() => videoInputRef.current?.click()}
                className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-dashed border-border/50 hover:border-violet-500/40 hover:bg-violet-500/5 transition-all group"
              >
                <div className="w-12 h-12 rounded-full bg-muted/60 flex items-center justify-center group-hover:bg-violet-500/15 transition-colors">
                  <Video className="w-6 h-6 text-muted-foreground group-hover:text-violet-400 transition-colors" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold">Video</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">MP4 · MOV · WebM</p>
                  <p className="text-[11px] text-muted-foreground">Up to 50 MB</p>
                </div>
              </button>
            </div>
          ) : (
            /* Preview */
            <div className="relative rounded-xl overflow-hidden border border-border/40 bg-black">
              {mediaType === "video" ? (
                <video
                  src={mediaPreviewUrl!}
                  controls
                  playsInline
                  className="w-full max-h-[320px] object-contain"
                />
              ) : (
                <img
                  src={mediaPreviewUrl!}
                  alt="Preview"
                  className="w-full max-h-[320px] object-contain"
                />
              )}

              {/* Overlay info bar */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent px-3 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${mediaType === "video" ? "bg-violet-500/80" : "bg-primary/80"}`}>
                    {mediaType === "video" ? <Video className="w-3.5 h-3.5 text-white" /> : <ImageIcon className="w-3.5 h-3.5 text-white" />}
                  </div>
                  <div>
                    <p className="text-white text-xs font-medium truncate max-w-[160px]">{mediaFile.name}</p>
                    <p className="text-white/60 text-[10px]">{formatBytes(mediaFile.size)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 text-green-400 text-[11px] font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                  </div>
                  <button
                    type="button"
                    onClick={clearMedia}
                    className="p-1.5 bg-black/60 hover:bg-destructive/80 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Change media when one is selected */}
          {mediaFile && (
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                className="flex-1 flex items-center justify-center gap-1.5 h-9 rounded-lg border border-border/50 text-xs text-muted-foreground hover:bg-muted/50 transition-colors"
              >
                <ImageIcon className="w-3.5 h-3.5" /> Change to photo
              </button>
              <button
                type="button"
                onClick={() => videoInputRef.current?.click()}
                className="flex-1 flex items-center justify-center gap-1.5 h-9 rounded-lg border border-border/50 text-xs text-muted-foreground hover:bg-muted/50 transition-colors"
              >
                <Video className="w-3.5 h-3.5" /> Change to video
              </button>
            </div>
          )}
        </div>

        {/* Upload progress */}
        {loading && uploadProgress > 0 && (
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-muted-foreground font-medium">
              <span>{uploadProgress < 90 ? "Uploading media..." : "Saving post..."}</span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-violet-500 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Hidden file inputs — strictly typed */}
      <input
        ref={imageInputRef}
        type="file"
        accept="image/jpeg,image/png,image/gif,image/webp,image/heic"
        onChange={handleImagePick}
        className="hidden"
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/mp4,video/quicktime,video/webm,video/x-msvideo,video/mpeg"
        onChange={handleVideoPick}
        className="hidden"
      />
    </div>
  );
}
