import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { TopBar } from "@/components/TopBar";
import { useProfile } from "@/hooks/useProfile";
import { supabase } from "@/lib/supabase";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { levelFromXp, xpProgress, xpToNextLevel, formatXp } from "@/utils/xp";
import { Flame, Zap, Target, Edit3 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function ProgressPage() {
  const { user } = useAuth();
  const { profile, loading: profileLoading } = useProfile(user?.id);
  const [progressData, setProgressData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProgress() {
      if (!user) return;
      const { data } = await supabase
        .from("user_progress")
        .select("*")
        .eq("user_id", user.id)
        .order("date", { ascending: true })
        .limit(7);
      
      const chartData = (data || []).map(d => ({
        name: new Date(d.date).toLocaleDateString('en-US', { weekday: 'short' }),
        xp: d.xp_earned,
        actions: d.actions_completed
      }));

      // Pad to 7 days if empty
      const padded = chartData.length > 0 ? chartData : [
        { name: "Mon", xp: 0, actions: 0 },
        { name: "Tue", xp: 0, actions: 0 },
        { name: "Wed", xp: 0, actions: 0 },
        { name: "Thu", xp: 0, actions: 0 },
        { name: "Fri", xp: 0, actions: 0 },
        { name: "Sat", xp: 0, actions: 0 },
        { name: "Sun", xp: 0, actions: 0 }
      ];

      setProgressData(padded);
      setLoading(false);
    }
    fetchProgress();
  }, [user]);

  if (profileLoading || loading) return <div className="p-4 text-center mt-20">Loading progress...</div>;

  const xp = profile?.xp || 0;
  const level = levelFromXp(xp);
  const currentXp = xpProgress(xp);
  const nextXp = xpToNextLevel(xp);
  const progressPercent = (currentXp / 100) * 100;

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <TopBar />
      <div className="flex-1 p-4 max-w-2xl mx-auto w-full space-y-6 mt-4">
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Your Progress</h1>
          <p className="text-muted-foreground">Every action compounds.</p>
        </div>

        <Card className="bg-card/50 backdrop-blur-xl border-primary/20">
          <CardContent className="p-6 text-center space-y-4">
            <div className="text-6xl font-black text-primary tracking-tighter drop-shadow-[0_0_15px_rgba(139,92,246,0.3)]">
              LVL {level}
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-muted-foreground tracking-wider uppercase">
                <span>{currentXp} XP</span>
                <span>{nextXp} TO NEXT</span>
              </div>
              <Progress value={progressPercent} className="h-3" />
              <p className="text-xs text-primary/80 font-medium">Total XP: {formatXp(xp)}</p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-card/50 border-border/50 text-center py-6">
            <Flame className="w-8 h-8 text-orange-500 mx-auto mb-2 drop-shadow-[0_0_10px_rgba(249,115,22,0.5)]" />
            <div className="text-3xl font-bold">{profile?.streak || 0}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Day Streak</div>
          </Card>
          <Card className="bg-card/50 border-border/50 text-center py-6">
            <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" />
            <div className="text-3xl font-bold">{profile?.completed_actions || 0}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Actions Done</div>
          </Card>
        </div>

        <Card className="bg-card/50 border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Weekly Activity (XP)</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={progressData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{fill: 'transparent'}}
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                />
                <Bar dataKey="xp" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
