import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";

// Pages
import AuthPage from "@/pages/auth";
import FeedPage from "@/pages/feed";
import CreatePage from "@/pages/create";
import ChatPage from "@/pages/chat";
import AIPage from "@/pages/ai";
import ProgressPage from "@/pages/progress";
import ProfilePage from "@/pages/profile";
import NotificationsPage from "@/pages/notifications";
import SettingsPage from "@/pages/settings";

import { BottomNav } from "@/components/BottomNav";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component }: { component: React.ComponentType<any> }) {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !user) {
      setLocation("/auth");
    }
  }, [user, loading, setLocation]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-primary">Loading...</div>;
  }

  if (!user) return null;

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-16">
      <Component />
      <BottomNav />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <Route path="/">
        {() => <ProtectedRoute component={FeedPage} />}
      </Route>
      <Route path="/feed">
        {() => <ProtectedRoute component={FeedPage} />}
      </Route>
      <Route path="/create">
        {() => <ProtectedRoute component={CreatePage} />}
      </Route>
      <Route path="/chat">
        {() => <ProtectedRoute component={ChatPage} />}
      </Route>
      <Route path="/ai">
        {() => <ProtectedRoute component={AIPage} />}
      </Route>
      <Route path="/progress">
        {() => <ProtectedRoute component={ProgressPage} />}
      </Route>
      <Route path="/profile">
        {() => <ProtectedRoute component={ProfilePage} />}
      </Route>
      <Route path="/notifications">
        {() => <ProtectedRoute component={NotificationsPage} />}
      </Route>
      <Route path="/settings">
        {() => <ProtectedRoute component={SettingsPage} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
