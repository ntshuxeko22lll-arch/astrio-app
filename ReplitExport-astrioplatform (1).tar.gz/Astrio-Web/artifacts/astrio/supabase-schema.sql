-- ============================================================
-- ASTRIO — COMPLETE DATABASE SCHEMA
-- Paste this entire file into Supabase SQL Editor and click Run
-- ============================================================

-- ============================================================
-- 1. PROFILES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id                UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username          TEXT NOT NULL,
  avatar_url        TEXT,
  bio               TEXT,
  goal              TEXT,
  xp                INTEGER NOT NULL DEFAULT 0,
  level             INTEGER NOT NULL DEFAULT 1,
  streak            INTEGER NOT NULL DEFAULT 0,
  completed_actions INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique ON public.profiles (LOWER(username));
CREATE INDEX        IF NOT EXISTS profiles_username_idx    ON public.profiles (username);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profiles_select ON public.profiles;
DROP POLICY IF EXISTS profiles_insert ON public.profiles;
DROP POLICY IF EXISTS profiles_update ON public.profiles;

CREATE POLICY profiles_select ON public.profiles FOR SELECT USING (true);
CREATE POLICY profiles_insert ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY profiles_update ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON public.profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ============================================================
-- 2. GOALS (preset categories shown in top bar)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.goals (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL UNIQUE,
  description TEXT,
  icon        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS goals_select ON public.goals;
CREATE POLICY goals_select ON public.goals FOR SELECT USING (true);

INSERT INTO public.goals (name, description, icon) VALUES
  ('Fitness',      'Build strength, endurance, and a healthy body',  '💪'),
  ('Business',     'Launch, grow, and scale your business',          '🚀'),
  ('Learning',     'Acquire skills and knowledge systematically',    '📚'),
  ('Productivity', 'Master your time, focus, and output',            '⚡'),
  ('Mindset',      'Build mental resilience and positive habits',    '🧠'),
  ('Finance',      'Build wealth and financial independence',        '💰'),
  ('Creativity',   'Develop creative skills and express yourself',   '🎨')
ON CONFLICT (name) DO NOTHING;

-- ============================================================
-- 3. POSTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.posts (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  content        TEXT NOT NULL,
  media_url      TEXT,
  media_type     TEXT CHECK (media_type IN ('image', 'video')),
  ai_summary     TEXT,
  action_step    TEXT,
  likes_count    INTEGER NOT NULL DEFAULT 0,
  comments_count INTEGER NOT NULL DEFAULT 0,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS posts_user_id_idx    ON public.posts (user_id);
CREATE INDEX IF NOT EXISTS posts_created_at_idx ON public.posts (created_at DESC);

ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS posts_select ON public.posts;
DROP POLICY IF EXISTS posts_insert ON public.posts;
DROP POLICY IF EXISTS posts_update ON public.posts;
DROP POLICY IF EXISTS posts_delete ON public.posts;

CREATE POLICY posts_select ON public.posts FOR SELECT USING (true);
CREATE POLICY posts_insert ON public.posts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY posts_update ON public.posts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY posts_delete ON public.posts FOR DELETE USING (auth.uid() = user_id);

DROP TRIGGER IF EXISTS posts_updated_at ON public.posts;
CREATE TRIGGER posts_updated_at
  BEFORE UPDATE ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ============================================================
-- 4. LIKES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.likes (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (post_id, user_id)
);

CREATE INDEX IF NOT EXISTS likes_post_id_idx ON public.likes (post_id);
CREATE INDEX IF NOT EXISTS likes_user_id_idx ON public.likes (user_id);

ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS likes_select ON public.likes;
DROP POLICY IF EXISTS likes_insert ON public.likes;
DROP POLICY IF EXISTS likes_delete ON public.likes;

CREATE POLICY likes_select ON public.likes FOR SELECT USING (true);
CREATE POLICY likes_insert ON public.likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY likes_delete ON public.likes FOR DELETE USING (auth.uid() = user_id);

-- ============================================================
-- 5. ACTIONS COMPLETED
-- ============================================================
CREATE TABLE IF NOT EXISTS public.actions_completed (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (post_id, user_id)
);

CREATE INDEX IF NOT EXISTS actions_post_id_idx ON public.actions_completed (post_id);
CREATE INDEX IF NOT EXISTS actions_user_id_idx ON public.actions_completed (user_id);

ALTER TABLE public.actions_completed ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS actions_select ON public.actions_completed;
DROP POLICY IF EXISTS actions_insert ON public.actions_completed;

CREATE POLICY actions_select ON public.actions_completed FOR SELECT USING (true);
CREATE POLICY actions_insert ON public.actions_completed FOR INSERT WITH CHECK (auth.uid() = user_id);

-- ============================================================
-- 6. COMMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.comments (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content    TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS comments_post_id_idx ON public.comments (post_id);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS comments_select ON public.comments;
DROP POLICY IF EXISTS comments_insert ON public.comments;
DROP POLICY IF EXISTS comments_delete ON public.comments;

CREATE POLICY comments_select ON public.comments FOR SELECT USING (true);
CREATE POLICY comments_insert ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY comments_delete ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- ============================================================
-- 7. MESSAGES (human chat only — is_ai=false for human threads)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.messages (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id   UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  is_ai       BOOLEAN NOT NULL DEFAULT false,
  read        BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS messages_sender_idx   ON public.messages (sender_id);
CREATE INDEX IF NOT EXISTS messages_receiver_idx ON public.messages (receiver_id);
CREATE INDEX IF NOT EXISTS messages_conv_idx     ON public.messages (sender_id, receiver_id, created_at DESC);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS messages_select ON public.messages;
DROP POLICY IF EXISTS messages_insert ON public.messages;
DROP POLICY IF EXISTS messages_update ON public.messages;

CREATE POLICY messages_select ON public.messages FOR SELECT
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);
CREATE POLICY messages_insert ON public.messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);
CREATE POLICY messages_update ON public.messages FOR UPDATE
  USING (auth.uid() = receiver_id);

-- ============================================================
-- 8. NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.notifications (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type       TEXT NOT NULL DEFAULT 'general',
  title      TEXT NOT NULL,
  body       TEXT NOT NULL DEFAULT '',
  read       BOOLEAN NOT NULL DEFAULT false,
  data       JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS notifications_user_id_idx ON public.notifications (user_id);
CREATE INDEX IF NOT EXISTS notifications_unread_idx  ON public.notifications (user_id, read) WHERE read = false;
CREATE INDEX IF NOT EXISTS notifications_created_idx ON public.notifications (created_at DESC);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS notifications_select ON public.notifications;
DROP POLICY IF EXISTS notifications_insert ON public.notifications;
DROP POLICY IF EXISTS notifications_update ON public.notifications;

CREATE POLICY notifications_select ON public.notifications FOR SELECT USING (auth.uid() = user_id);
-- Allow the app (authenticated users) to create notifications for any user
CREATE POLICY notifications_insert ON public.notifications FOR INSERT WITH CHECK (true);
CREATE POLICY notifications_update ON public.notifications FOR UPDATE USING (auth.uid() = user_id);

-- ============================================================
-- 9. USER PROGRESS (one row per user per day)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.user_progress (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  date              DATE NOT NULL,
  xp_earned         INTEGER NOT NULL DEFAULT 0,
  actions_completed INTEGER NOT NULL DEFAULT 0,
  posts_created     INTEGER NOT NULL DEFAULT 0,
  streak_day        INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, date)
);

CREATE INDEX IF NOT EXISTS progress_user_date_idx ON public.user_progress (user_id, date DESC);

ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS progress_select ON public.user_progress;
DROP POLICY IF EXISTS progress_insert ON public.user_progress;
DROP POLICY IF EXISTS progress_update ON public.user_progress;

CREATE POLICY progress_select ON public.user_progress FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY progress_insert ON public.user_progress FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY progress_update ON public.user_progress FOR UPDATE USING (auth.uid() = user_id);

-- ============================================================
-- 10. ENABLE REALTIME (for live notifications + chat)
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- ============================================================
-- DONE! Now create these two Storage buckets in Supabase:
--
--   Bucket name: post-media   → Public: ON
--   Bucket name: avatars      → Public: ON
--
-- For each bucket add these Storage Policies:
--   SELECT policy: bucket_id IN ('post-media','avatars')   → true
--   INSERT policy: bucket_id IN ('post-media','avatars')   → auth.role() = 'authenticated'
-- ============================================================
